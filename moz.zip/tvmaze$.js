/* global Update(type:string, details:object) */
(init = () => Update('SCRIPT', { script: 'tvmaze' }))();
