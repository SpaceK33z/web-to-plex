/* global sendUpdate(type:string, details:object) */
(init = () => sendUpdate('SCRIPT', { script: 'metacritic' }))();
